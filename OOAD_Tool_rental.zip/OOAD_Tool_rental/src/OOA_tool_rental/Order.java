package OOA_tool_rental;

public class Order {
	private Cost_accessory additional_cost;

	
	public Order(Cost_accessory additional_cost) {
		this.additional_cost=additional_cost;
	}
	
	

}

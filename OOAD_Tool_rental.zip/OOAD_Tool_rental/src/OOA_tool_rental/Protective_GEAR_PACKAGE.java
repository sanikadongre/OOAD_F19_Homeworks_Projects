package OOA_tool_rental;

public interface Protective_GEAR_PACKAGE {
	void add_gear_package();
}

package OOA_tool_rental;

public interface Extension_cord {
	void add_extension_cord();

}

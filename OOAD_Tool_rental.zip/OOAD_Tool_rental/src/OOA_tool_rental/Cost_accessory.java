package OOA_tool_rental;

public interface Cost_accessory {
	int get_price_accessory_kit();

}

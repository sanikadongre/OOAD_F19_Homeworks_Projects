package OOA_tool_rental;

public interface Accessory_kit {
	void add_accessory_kit();
}

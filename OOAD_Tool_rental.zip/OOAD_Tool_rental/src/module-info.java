module OOAD_Tool_rental {
}
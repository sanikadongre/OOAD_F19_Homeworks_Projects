package OOA_tool_rental;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class Inventory {
	/*Tool rental base inventory class*/


	static List<String> tools_in_use_list = new ArrayList<>();
	int count =5;
    String tool="Unknown";
    int price=0;
    String cust_name="Unknown";
    int accessory_kit_price=0;
    int gear_package_price=0;
    int extension_cord_price=0;
  
    Map<String,Integer> days_count = new HashMap<>();
	public abstract int getPrice();
	public String get_ToolList() {
		return tool;
	}

	
	public int get_count_tools() {
		return count;
	}
	public List<String> get_tools_in_use_list(){
		return tools_in_use_list;
	}
	public void update_days(String cust_name, int days) {
		
	}
	public int get_gear_package_price() {
		return gear_package_price;	
	}

	public int get_extension_cord_price() {
		return extension_cord_price;	
	}
	public int get_price_accessory_kit() {
		return accessory_kit_price;	
	}
	public  void set_price() {
		
	}
}

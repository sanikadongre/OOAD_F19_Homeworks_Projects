package OOA_tool_rental;
import java.io.*; 

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Order_main {
	public static void main(String args[]) throws FileNotFoundException {
		int days_count =1;
		int tools_Available = 24;
		int total_overall_profit=0;
		int NO_OF_DAYS_STORE_IS_OPERATIONAL = 35;
		
		PrintStream o = new PrintStream(new File("OUTPUT.txt"));
		
		PrintStream console = System.out; 
		  
        // Assign o to output stream 
        System.setOut(o); 
		StringBuilder stringBuilder = new StringBuilder();
		
		Order_Observer obj_obs = new Order_Obser_Class();
		Test_Case_1 tst = new Test_Case_1();
		
		Order obj = new Order();
		Random random = new Random();
		ArrayList<RentalRecordStore> rrstore = new ArrayList<RentalRecordStore>();
		while(days_count <=NO_OF_DAYS_STORE_IS_OPERATIONAL ) {
				int profit_per_day = 0;
		      int customersOnTheDay = random.nextInt(2)+1; //randomly select between 1 and 2 customers, on any given day.
		      boolean day_count_changed = true;
		      for (int i=1;i<=customersOnTheDay;i++) {
		        HashMap<String, String>  toolsProfitMap = obj.order_func(days_count,i,tools_Available,rrstore,day_count_changed);
		         tools_Available -= Integer.parseInt(toolsProfitMap.get("tool_cnt"));
		         profit_per_day += Integer.parseInt(toolsProfitMap.get("total_profit"));
		         stringBuilder.append(toolsProfitMap.get("rental_records"));
		         day_count_changed = false;
		      }
		      total_overall_profit += profit_per_day;
		      if (days_count == NO_OF_DAYS_STORE_IS_OPERATIONAL) {
		      	obj_obs.update_Observer(days_count,tools_Available,profit_per_day, total_overall_profit, stringBuilder.toString());
				} else {
		      	obj_obs.update_Observer(days_count,tools_Available,profit_per_day, total_overall_profit, "Do not print yet");
				}
		      days_count++;
		 }
		System.out.println("--------------Test Case Execution begins-------------------");
		tst.test1();
		tst.test2();
		tst.test3();
		tst.test4();
		tst.test5();
		tst.test6();
		tst.test7();
		tst.test8();
		tst.test9();
		tst.test10();
		System.out.println("----------------Test Case Execution Ends---------------------");
	}
}

package OOA_tool_rental;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class Test_Case_1 {

	@Test
	void test1() {
		/*Testing decorator pattern for Accessory_kit*/
		Painting obj = new Painting("JOSH");
		Plumbing obj1 = new  Plumbing("JOSH");
		
		Accessory_kit tester1 = new Accessory_kit(obj);
		Accessory_kit tester2 = new Accessory_kit(obj1);
		
		assertEquals(10,tester1.getPrice());
		assertEquals(12,tester2.getPrice());
		
		
	}
	@Test
	void test2() {
		/*Testing decorator pattern for Protective_GEAR_PACKAGE*/
		Painting obj = new Painting("JOSH");
		Plumbing obj1 = new  Plumbing("JOSH");
		
		Protective_GEAR_PACKAGE tester1 = new Protective_GEAR_PACKAGE(obj);
		Protective_GEAR_PACKAGE tester2 = new Protective_GEAR_PACKAGE(obj1);
		
		assertEquals(11,tester1.getPrice());
		assertEquals(13,tester2.getPrice());
		
		
	}
	@Test
	void test3() {
		/*Testing decorator pattern for Extension_cord*/
		Painting obj = new Painting("JOSH");
		Plumbing obj1 = new  Plumbing("JOSH");
		
		Extension_cord tester1 = new Extension_cord(obj);
		Extension_cord tester2 = new Extension_cord(obj1);
		
		assertEquals(12,tester1.getPrice());
		assertEquals(14,tester2.getPrice());
		
		
	}
	@Test
	void test4() {
		/*To test if the cost of tools is updated when they are selected*/
		InventoryFactory inventoryFactory= new InventoryFactory();
		Inventory inventory = inventoryFactory.createTool("PLUMBING","JOSH");
		inventory.get_ToolList(); 
		inventory.set_price();
		assertEquals(70,inventory.getPrice());

	}
	@Test
	void test5() {
		/*To test if the cost of tools is updated when they are selected*/
		InventoryFactory inventoryFactory= new InventoryFactory();
		Inventory inventory = inventoryFactory.createTool("PAINTING","JOSH");
		inventory.get_ToolList(); 
		inventory.set_price();
		assertEquals(50,inventory.getPrice());

	}
	@Test
	void test6() {
		/*Testing decorator pattern for Accessory_kit*/
		Concrete obj2 = new Concrete("JOSH");
		Woodwork obj3 = new Woodwork("JOSH");
		YardWork obj4 = new YardWork("JOSH");
		Accessory_kit tester3 = new Accessory_kit(obj2);
		Accessory_kit tester4 = new Accessory_kit(obj3);
		Accessory_kit tester5 = new Accessory_kit(obj4);
		assertEquals(15,tester3.getPrice());
		assertEquals(18,tester4.getPrice());
		assertEquals(20,tester5.getPrice());

	}
	@Test
	void test7() {
		/*Testing decorator pattern for Protective_GEAR_PACKAGE*/
		Concrete obj2 = new Concrete("JOSH");
		Woodwork obj3 = new Woodwork("JOSH");
		YardWork obj4 = new YardWork("JOSH");
		Protective_GEAR_PACKAGE tester3 = new Protective_GEAR_PACKAGE(obj2);
		Protective_GEAR_PACKAGE tester4 = new Protective_GEAR_PACKAGE(obj3);
		Protective_GEAR_PACKAGE tester5 = new Protective_GEAR_PACKAGE(obj4);
		assertEquals(16,tester3.getPrice());
		assertEquals(19,tester4.getPrice());
		assertEquals(21,tester5.getPrice());

	}
	void test8() {
		/*Testing decorator pattern for Extension_cord*/
		Concrete obj2 = new Concrete("JOSH");
		Woodwork obj3 = new Woodwork("JOSH");
		YardWork obj4 = new YardWork("JOSH");
		Extension_cord tester3 = new Extension_cord(obj2);
		Extension_cord tester4 = new Extension_cord(obj3);
		Extension_cord tester5 = new Extension_cord(obj4);
		assertEquals(17,tester3.getPrice());
		assertEquals(20,tester4.getPrice());
		assertEquals(22,tester5.getPrice());

	}
	void test9() {
		/*To test if the delta value of the tool_list is returned correctly*/
		Reduce_days obj= new  Reduce_days();
		List<String> tools_pre = Arrays.asList("PAINT_CAN","TRAY","ROLLER","TAPE","PAINT_BRUSH","WRENCH","SPANNER","PLIER","PLUNGER","HOSE_PIPE","MIXER","WHEEL_BARROW","SHOVEL","LEVEL","DRILL","HAMMER","KNIFE","CHISEL","NAIL","SLIDING_BEVEL","WEEDER","GARDEN_SCISSORS","TROWEL","SPADE");
		List<String> tools_used=Arrays.asList("PAINT_CAN","TRAY","ROLLER","TAPE","PAINT_BRUSH","WRENCH","SPANNER","PLIER","PLUNGER","HOSE_PIPE","MIXER","WHEEL_BARROW","SHOVEL","LEVEL","DRILL","HAMMER","KNIFE","CHISEL","NAIL","SLIDING_BEVEL","WEEDER","GARDEN_SCISSORS","TROWEL");
		assertEquals(Arrays.asList("SPADE"),obj.subtract(tools_pre,tools_used));

	}
	void test10() {
		/*To test if the cost of tools is updated when they are selected*/
		InventoryFactory inventoryFactory= new InventoryFactory();
		Inventory inventory = inventoryFactory.createTool("CONCRETE","JOSH");
		inventory.get_ToolList(); 
		inventory.set_price();
		assertEquals(50,inventory.getPrice());

	}
	

}

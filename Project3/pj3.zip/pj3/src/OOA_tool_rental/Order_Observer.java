package OOA_tool_rental;

interface Order_Observer {
	int days_count =1;
	int tools_Available = 24;
	int profit_per_day = 0;
	
	void update_Observer(int x,int y,int z, int p, String q);
	void announce_event();
 
}
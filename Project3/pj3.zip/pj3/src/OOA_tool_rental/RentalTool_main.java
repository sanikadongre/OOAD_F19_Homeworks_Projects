package OOA_tool_rental;

import java.util.HashMap;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RentalTool_main {
	Random random = new Random();
	private InventoryFactory inventoryFactory;
	public int cust_id;
	public String cust_name;
	private int cost;
	private int additional_cost=0;
	private String tool_selection;
	public RentalTool_main(InventoryFactory inventoryFactory) {
		this.inventoryFactory=inventoryFactory;
	}

	public HashMap<String, String> orderTool(String Tooltype, String cust_name,String customer_type,ArrayList<RentalRecordStore> rrstore) {
		HashMap<String,String> returnMap = new HashMap<>();
		StringBuilder stringBuilder = new StringBuilder();
		InventoryFactory inventoryFactory= new InventoryFactory();
		Inventory inventory = inventoryFactory.createTool(Tooltype,cust_name);
		tool_selection=inventory.get_ToolList();
		if (tool_selection.contentEquals("All tools in this category are rented")) {
			System.out.println("All tools in this category are rented. Please make another category selection");
			returnMap.put("minus_one", "-1");
			return returnMap;
		} else if (tool_selection.contentEquals("The tool has already been rented")) {
			System.out.println("The tool has already been rented. Please make another tool selection");
			returnMap.put("zero", "0");
			return returnMap;
		} else {
			System.out.println("You have selected "+tool_selection+" for "+cust_name);
		}
		System.out.println("How many accessories do you want to add?");
		//Scanner input = new Scanner(System.in);
		int count = random.nextInt(2)+1;
		System.out.println("Count is "+count);
		RentalTool_main obj = new RentalTool_main(inventoryFactory);
		for(int i=0;i<count;i++) {
			additional_cost=obj.accessory_order(inventory)+additional_cost;
		}

		/*additional_cost=inventory.get_price_accessory_kit();*/
		int count_Days =0;
		if(customer_type.equalsIgnoreCase("REGULAR")) {
			System.out.println("For how many nights do you want to rent the tool? Choose between 3 to 5");
			count_Days += random.nextInt(2)+3;
			
		}
		else if(customer_type.equalsIgnoreCase("CASUAL")) {
			System.out.println("For how many nights do you want to rent the tool? Choose between 1 to 2");
			count_Days += random.nextInt(1)+1;
		}
		else if(customer_type.equalsIgnoreCase("BUSINESS")) {
			System.out.println("You have to rent the tool for 7 nights");
			count_Days += 7;
		}
		System.out.println("Number of nights chosen to rent"+count_Days+"\n");
		System.out.println("SELECTED TOOL : "+tool_selection);
		inventory.update_days(tool_selection, count_Days);
		inventory.set_price();
		cost=inventory.getPrice();
		int total =(cost+additional_cost) * count_Days;
		RentalRecordStore rrstoreObj= new RentalRecordStore(cust_name,customer_type,tool_selection,count_Days,total);
		rrstore.add(rrstoreObj);
		//add successful transaction entry to the ledger
		stringBuilder.append("[Ledger] Rented by " + cust_name + " of customer type: " + customer_type
            + " who spent on rental $" + total);
		
		System.out.println("Cost of tool per day "+cost+"$");
		System.out.println("Additional Cost for option per day "+additional_cost+"$");
		System.out.println("You need to pay "+total+"$\n");
		//rrstoreObj.printRecord();
		
		//input.close();
		//return inventory;
		System.out.println("Record created for the transaction");
		returnMap.put("total", Integer.toString(total));
		returnMap.put("record", stringBuilder.toString());
		return returnMap;
	}
	public int accessory_order(Inventory inventory) {
		ArrayList<String> accessoryList = new ArrayList<>();
      accessoryList.add("A");
      accessoryList.add("B");
      accessoryList.add("C");
		System.out.println("Select an option : A-accessory Kit, B- Gear Package, C-Extension cord");
		//Scanner input = new Scanner(System.in);
		//Scanner cust = new Scanner(System.in);
		String accessory = accessoryList.get(random.nextInt(2));
		System.out.println("Accesssory chosen: "+accessory);
		switch(accessory.toUpperCase()) {
		case "A":
			inventory = new Accessory_kit(inventory);
			break;
		case "B":
			inventory = new Protective_GEAR_PACKAGE(inventory);
			break;
		case "C":
			inventory = new Extension_cord(inventory);
			break;
		}
		//cust.close();
		return inventory.getPrice();
	}
	

}

package OOA_tool_rental;

import java.util.ArrayList;
import java.util.List;

import java.util.*;

public class Painting extends Inventory {

   public enum Tool {
      PAINT_CAN, TRAY, ROLLER, TAPE, PAINT_BRUSH
   }

   private static List<String> tools_in_use_list = new ArrayList<>();
   private static int count = 5;
   private String tool;
   private int price;
   private int accessory_kit_price;
   private int gear_package_price;
   private int extension_cord_price;

   private String cust_name;
   private boolean flag = false;
   private static Map<String, Integer> days_count = new HashMap<>();

   public Painting() {
      for (String key : days_count.keySet()) {
         if ((days_count.get(key) != 0)) {
            days_count.replace(key, days_count.get(key) - 1);
         }
      }

   }

   public Painting(String cust_name) {
      super();
      for (String key : days_count.keySet()) {
         if (days_count.get(key) == 0) {
            tools_in_use_list.remove(key);

         }
      }
      this.cust_name = cust_name;
      this.accessory_kit_price = 10;
      this.gear_package_price = 11;
      this.extension_cord_price = 12;
   }

   @Override
   public String get_ToolList() {

      List<String> list = new ArrayList<>();
      // add 5 element in ArrayList
      list.add("PAINT_CAN");
      list.add("TRAY");
      list.add("ROLLER");
      list.add("TAPE");
      list.add("PAINT_BRUSH");

      System.out.println("Tools in Painting are: ");

      if (tools_in_use_list.size() < 5) {
         for (Tool t : Tool.values()) {
            System.out.println(t.name());
         }
      } else {
         if (tools_in_use_list.size() == 5) {
            return "All tools in this category are rented";
         }
      }

      String tool_input = getRandomElement(list);

      while (flag == false) {
         if (tools_in_use_list.contains(tool_input.toUpperCase())) {
            System.out.println("The tool has already been rented. Please select something else");
            tool_input = getRandomElement(list);
         } else {
            flag = true;
         }
      }
      tools_in_use_list.add(tool_input.toUpperCase());
      return tool_input;
   }

   public String getRandomElement(List<String> list) {
      Random rand = new Random();
      return list.get(rand.nextInt(list.size()));
   }

   @Override
   public void set_price() {
      this.price = 50;
   }

   @Override
   public int get_count_tools() {
      return tools_in_use_list.size();
   }

   public void update_days(String tool_selection, int days) {
      days_count.put(tool_selection, days);
   }

   @Override

   public int getPrice() {
      return price;
   }

   @Override

   public int get_price_accessory_kit() {
      return this.accessory_kit_price;
   }

   @Override

   public int get_gear_package_price() {
      return this.gear_package_price;
   }

   @Override

   public int get_extension_cord_price() {
      return this.extension_cord_price;
   }

   @Override

   public List<String> get_tools_in_use_list() {
      return tools_in_use_list;
   }
}
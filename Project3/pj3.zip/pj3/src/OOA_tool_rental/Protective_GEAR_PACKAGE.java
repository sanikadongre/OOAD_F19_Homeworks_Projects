package OOA_tool_rental;

public class Protective_GEAR_PACKAGE extends Cost_accessory{
	Inventory inventory;
	public Protective_GEAR_PACKAGE(Inventory inventory) {
		this.inventory=inventory;
	}
	@Override
	public int getPrice() {
		return inventory.get_gear_package_price();
	}
}

package OOA_tool_rental;

public class Accessory_kit extends Cost_accessory{
	Inventory inventory;
	public Accessory_kit(Inventory inventory) {
		this.inventory=inventory;
	}
	@Override
	public int getPrice() {
		return inventory.get_price_accessory_kit();
	}
}

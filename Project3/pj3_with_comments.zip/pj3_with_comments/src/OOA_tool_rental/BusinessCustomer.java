package OOA_tool_rental;

public class BusinessCustomer {
	String type,name;
	public BusinessCustomer(String name) {
		this.name = name;
		this.type = "business";
	}
}

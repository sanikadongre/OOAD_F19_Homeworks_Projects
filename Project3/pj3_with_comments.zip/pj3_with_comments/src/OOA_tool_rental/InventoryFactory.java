package OOA_tool_rental;

public class InventoryFactory {
	public Inventory createTool(String ToolType, String cust_name) {
		if(ToolType == null) {
			return null;
		}
		if(ToolType.equalsIgnoreCase("PAINTING")) {
			return new Painting(cust_name);
		}
		else if(ToolType.equalsIgnoreCase("PLUMBING")) {
			return new Plumbing(cust_name);
		}
		else if(ToolType.equalsIgnoreCase("CONCRETE")) {
			return new Concrete(cust_name);
		}
		else if(ToolType.equalsIgnoreCase("WOODWORK")) {
			return new Woodwork(cust_name);
		}
		else if(ToolType.equalsIgnoreCase("YARDWORk")) {
			return new YardWork(cust_name);
		}
		return null;
		
	}

}

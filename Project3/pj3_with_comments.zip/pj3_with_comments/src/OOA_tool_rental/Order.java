package OOA_tool_rental;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class Order {

   public HashMap<String, String> order_func(int days_count, int customer_no, int tools_Available,
         ArrayList<RentalRecordStore> rrstore, boolean day_count_changed) {

      /*-- Prepare Data for random selection --- */
      Random random = new Random();
      ArrayList<String> customerTypes1 = new ArrayList<>();
      customerTypes1.add("REGULAR");
      customerTypes1.add("CASUAL");
      customerTypes1.add("BUSINESS");
      ArrayList<String> customerTypes2 = new ArrayList<>();
      customerTypes2.add("REGULAR");
      customerTypes2.add("CASUAL");
      ArrayList<String> regularCustomerNames = new ArrayList<>();
      regularCustomerNames.add("JOEY");
      regularCustomerNames.add("CHANDLER");
      regularCustomerNames.add("ROSS");
      regularCustomerNames.add("GUNTHER");
      ArrayList<String> casualCustomerNames = new ArrayList<>();
      casualCustomerNames.add("RACHEL");
      casualCustomerNames.add("MONICA");
      casualCustomerNames.add("JANICE");
      casualCustomerNames.add("PHOEBE");
      ArrayList<String> businessCustomerNames = new ArrayList<>();
      businessCustomerNames.add("BEN");
      businessCustomerNames.add("EMMA");
      businessCustomerNames.add("KEN");
      businessCustomerNames.add("REGINA");
      ArrayList<String> toolCategories = new ArrayList<>();
      toolCategories.add("PAINTING");
      toolCategories.add("CONCRETE");
      toolCategories.add("PLUMBING");
      toolCategories.add("WOODWORK");
      toolCategories.add("YARDWORK");

      /*---------------------------------*/

      ArrayList<String> toolsInUse = new ArrayList<>();

      InventoryFactory inventoryFactory = new InventoryFactory();
      RentalTool_main rental = new RentalTool_main(inventoryFactory);
      StringBuilder stringBuilder = new StringBuilder();
     
      if (day_count_changed) {
         Reduce_days rd = new Reduce_days();
         List<String> tools_rem = new ArrayList<>();
         tools_rem = rd.get_difference();
         System.out.println("-------------------------- DAY "+days_count+" --------------------------");
         System.out.println("--------------------------- TOOLS COUNT IS :"+tools_rem.size()+" -------------------------\n");
         System.out.println("--------------------------- TOOLS AVAILABLE ARE -------------------------\n");
         for (int i = 0; i < tools_rem.size(); i++) {
            System.out.print(tools_rem.get(i) + "  ");
            if (i > 1 && i % 10 == 0) {
               System.out.println("\n");
            }
         }
         System.out.println("\n");
         if (days_count > 1) {
            int k = rrstore.size();
            for (int i = 0; i < k; i++) {
               System.out.println("Record for the day is " + rrstore.get(i));
            }
         }
      }

      System.out.println("---------------------------Customer Number: " + customer_no + "---------------------------");

      String customer_type = "";

      //Scanner cust = new Scanner(System.in);
      if (tools_Available < 3) {
         System.out.println("Choose the type of customer: REGULAR or CASUAL");
         customer_type = customerTypes2.get(random.nextInt(1));
      } else {
         System.out.println("Choose the type of customer: REGULAR, CASUAL, BUSINESS");
         customer_type = customerTypes1.get(random.nextInt(2));
      }

      System.out.println("WELCOME " + customer_type + " CUSTOMER");
      String customer_name = "";
      int count_tools = 0;

      if (customer_type.equalsIgnoreCase("REGULAR")) {
         System.out.println("What is your name? 1.JOEY 2.CHANDLER 3.ROSS 4.GUNTHER");
         customer_name = regularCustomerNames.get(random.nextInt(3));
         RegularCustomer custObj = new RegularCustomer(customer_name);
         System.out.println("Hi " + custObj.name+"\n");
         System.out.println("How many tools you want to buy? You can choose from 1 to 3 only!!");
         count_tools += (random.nextInt(2)+1);
         
      } else {
         if (customer_type.equalsIgnoreCase("CASUAL")) {
            System.out.println("What is your name? 1.RACHEL 2.MONICA 3.JANICE 4.PHOEBE");
            customer_name = casualCustomerNames.get(random.nextInt(3));
            CasualCustomer custObj = new CasualCustomer(customer_name);
            System.out.println("Hi " + custObj.name+"\n");
            System.out.println("How many tools you want to buy? You can choose from 1 to 2 only!!");
            count_tools += (random.nextInt(1)+1);
         } else {
            if (customer_type.equalsIgnoreCase("BUSINESS")) {
               System.out.println("What is your name? 1.BEN 2.EMMA 3.KEN 4.REGINA");
               customer_name = businessCustomerNames.get(random.nextInt(3));
               BusinessCustomer custObj = new BusinessCustomer(customer_name);
               System.out.println("Hi " + custObj.name+"\n");
               System.out.println("You need to choose 3 tools!!");
               count_tools += 3;
            }
         }
      }
      System.out.println("You chose to buy "+count_tools+" tools");
      //Scanner input = new Scanner(System.in);
      String[] tool_category = new String[count_tools];
      int tool_cnt = count_tools;
      int i = 0;

      int total_profit = 0;
      while (count_tools > 0) {

         System.out.println("Choose the " + (i + 1)
               + " category you want to buy: PAINTING, CONCRETE, PLUMBING, WOODWORK, YARDWORK");
         tool_category[i] = toolCategories.get(random.nextInt(4));
         HashMap<String, String> transactionResponse = rental
               .orderTool(tool_category[i], customer_name, customer_type, rrstore);
         if (transactionResponse.containsKey("minus_one")) {
            //because user must reselect the category
            continue;
         } else {
            total_profit += Integer.parseInt(transactionResponse.get("total"));
            stringBuilder.append(transactionResponse.get("record"));
            stringBuilder.append("###");
            i++;
            count_tools--;
         }
      }

      //Print the transaction record
      int k = rrstore.size();
      for (i = 0; i < k; i++) {
         System.out.println("Record is " + rrstore.get(i));
      }

      // Send the tool count, profit and records created per transaction, back to main()
      HashMap<String, String> toolsAndProfitsMap = new HashMap<>();
      toolsAndProfitsMap.put("total_profit", Integer.toString(total_profit));
      toolsAndProfitsMap.put("tool_cnt", Integer.toString(tool_cnt));
      toolsAndProfitsMap.put("rental_records", stringBuilder.toString());
      return toolsAndProfitsMap;
   }
}
package OOA_tool_rental;

public class RegularCustomer {
	String type,name;
	public RegularCustomer(String name) {
		this.name = name;
		this.type = "regular";
	}
}

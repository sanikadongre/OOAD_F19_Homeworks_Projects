package OOA_tool_rental;


public class Extension_cord extends Cost_accessory{
	Inventory inventory;
	public Extension_cord(Inventory inventory) {
		this.inventory=inventory;
	}
	@Override
	public int getPrice() {
		return inventory.get_extension_cord_price();
	}
}

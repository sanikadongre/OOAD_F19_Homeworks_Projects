package OOA_tool_rental;
import java.lang.reflect.Field;

public class RentalRecordStore {
	public String customer_name,customer_type, tool;
	public int days,fee;
	public RentalRecordStore(String customer,String customerType,String tool, int days, int fee){
		this.customer_name = customer;
		this.customer_type = customerType;
		this.tool = tool;
		this.days = days;
		this.fee = fee;
	}
	
	public String toString() {
		  StringBuilder result = new StringBuilder();
		  String newLine = System.getProperty("line.separator");

		  result.append( this.getClass().getName() );
		  result.append( " Object {" );
		  result.append(newLine);

		  //determine fields declared in this class only (no fields of superclass)
		  Field[] fields = this.getClass().getDeclaredFields();

		  //print field names paired with their values
		  for ( Field field : fields  ) {
		    result.append("  ");
		    try {
		      result.append( field.getName() );
		      result.append(": ");
		      //requires access to private field:
		      result.append( field.get(this) );
		    } catch ( IllegalAccessException ex ) {
		      System.out.println(ex);
		    }
		    result.append(newLine);
		  }
		  result.append("}");

		  return result.toString();
		}
	public void printR() {
			String rec = this.toString();
		    System.out.println("Record is"+rec.toString());
		
	}
	
}

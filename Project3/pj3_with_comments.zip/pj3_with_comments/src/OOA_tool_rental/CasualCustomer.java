package OOA_tool_rental;

public class CasualCustomer {
	String type,name;
	public CasualCustomer(String name) {
		this.name = name;
		this.type = "casual";
	}
}

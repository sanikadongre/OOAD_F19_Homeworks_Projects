package OOA_tool_rental;

import OOA_tool_rental.Plumbing.Tool;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

public class Plumbing extends Inventory {
   public enum Tool {
      WRENCH, SPANNER, PLIER, PLUNGER, HOSE_PIPE
   }

   private static List<String> tools_in_use_list = new ArrayList<>();
   private static int count = 5;
   private int price;
   private String tool;
   private int accessory_kit_price;
   private int gear_package_price;
   private int extension_cord_price;
   private String cust_name;
   private boolean flag = false;
   private static Map<String, Integer> days_count = new HashMap<>();

   public Plumbing() {
      for (String key : days_count.keySet()) {
         if ((days_count.get(key) != 0)) {
            days_count.replace(key, days_count.get(key) - 1);
         }
      }

   }

   public Plumbing(String cust_name) {
      super();
      for (String key : days_count.keySet()) {
         if (days_count.get(key) == 0) {
            tools_in_use_list.remove(key);

         }
      }
      this.cust_name = cust_name;

      this.accessory_kit_price = 12;
      this.gear_package_price = 13;
      this.extension_cord_price = 14;

   }

   public String get_ToolList() {

      List<String> list = new ArrayList<>();
      // add 5 element in ArrayList
      list.add("WRENCH");
      list.add("HOSE_PIPE");
      list.add("SPANNER");
      list.add("PLIER");
      list.add("PLUNGER");

      System.out.println("Tools in Plumbing are: ");
      if (tools_in_use_list.size() < 5) {
         for (Tool t : Tool.values()) {
            System.out.println(t.name());
         }
      } else {
         if (tools_in_use_list.size() == 5) {
            return "All tools in this category are rented";
         }
      }

      System.out.println("Enter the selection:");
      Scanner input1 = new Scanner(System.in);
      String tool_input = getRandomElement(list);
      //input1.close();
      while (flag == false) {
         if (tools_in_use_list.contains(tool_input)) {
            System.out.println("The tool has already been rented. Please select something else");
            tool_input = getRandomElement(list);
         } else {
            flag = true;
         }
      }
      tools_in_use_list.add(tool_input);
      return tool_input;
   }

   public String getRandomElement(List<String> list) {
      Random rand = new Random();
      return list.get(rand.nextInt(list.size()));
   }

   @Override
   public void set_price() {
      this.price = 70;
   }

   @Override
   public int get_count_tools() {
      return tools_in_use_list.size();
   }

   public void update_days(String tool_selection, int days) {
      days_count.put(tool_selection, days);
   }

   @Override

   public int getPrice() {
      return price;
   }

   @Override

   public int get_price_accessory_kit() {
      return this.accessory_kit_price;
   }

   @Override

   public int get_gear_package_price() {
      return this.gear_package_price;
   }

   @Override

   public int get_extension_cord_price() {
      return this.extension_cord_price;
   }

   @Override

   public List<String> get_tools_in_use_list() {
      return tools_in_use_list;
   }

}
package OOA_tool_rental;

public class Order_Obser_Class implements Order_Observer{
	public static int days_count =1;
	private static int tools_Available = 24;
	private static int profit_per_day = 0;
	private  static int total_Profit = 0;
	String rental_records;
	
	public void update_Observer(int day_count,int tools_available,int profit, int totalProfit, String rentals) {
		days_count = day_count;
		tools_Available=tools_available;
		profit_per_day = profit;
		total_Profit = totalProfit;
		rental_records = rentals;
		this.announce_event();
	}

	//Observer pattern - print per day and eventual data after 35 days rental
	public void announce_event() {
		
        System.out.println("-------------------------- MONEY MADE IN DAY "+days_count+" IS $"+profit_per_day+" -------------------------- ");
        System.out.println("-------------------------- TOTAL MONEY AT THE END OF DAY "+days_count+" IS $"+total_Profit+" -------------------------- ");
        if(!rental_records.equalsIgnoreCase("Do not print yet")) {
        		String[] records = rental_records.split("###");
        		System.out.println("\n-------------------------- TOTAL RENTALS THAT HAPPENED IS "+records.length+" --------------------------\n");
        		System.out.println("-------------------------- PRINTING ALL RECORDS AT THE END OF " +days_count+" DAYS -------------------------- ");
        		for(String record: records) {
					System.out.println(record);
				}
				System.out.println("-------------------------- COMPLETED -------------------------- ");
		  }
	}
}

package OOA_tool_rental;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.*;

public class Reduce_days {
	private static List<String> tools_used = new ArrayList<>();
	public Reduce_days() {
	Painting a = new Painting();
	Plumbing b = new Plumbing();
	Concrete c = new Concrete();
	Woodwork d = new Woodwork();
	YardWork e = new YardWork();
	
	for(String k : a.get_tools_in_use_list())
		tools_used.add(k);
	for(String k : b.get_tools_in_use_list())
		tools_used.add(k);
	for(String k : c.get_tools_in_use_list())
		tools_used.add(k);
	for(String k : d.get_tools_in_use_list())
		tools_used.add(k);
	for(String k : e.get_tools_in_use_list())
		tools_used.add(k);
	}
	
	public List<String> get_difference() {
		List<String> tools_pre = Arrays.asList("PAINT_CAN","TRAY","ROLLER","TAPE","PAINT_BRUSH","WRENCH","SPANNER","PLIER","PLUNGER","HOSE_PIPE","MIXER","WHEEL_BARROW","SHOVEL","LEVEL","DRILL","HAMMER","KNIFE","CHISEL","NAIL","SLIDING_BEVEL","WEEDER","GARDEN_SCISSORS","TROWEL","SPADE");
		List<String> result = subtract(tools_pre, tools_used);
		return result;
	}
	public <T> List<T> subtract(List<T> list1, List<T> list2) {
        List<T> result = new ArrayList<T>();
        Set<T> set2 = new HashSet<T>(list2);
        for (T t1 : list1) {
            if( !set2.contains(t1) ) {
                result.add(t1);
            }
        }
        return result;
    }
	
}

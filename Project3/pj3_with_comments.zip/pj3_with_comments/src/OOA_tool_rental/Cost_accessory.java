package OOA_tool_rental;

//abstract class for functionality definition. getPrice() is overridden across subclasses.
public abstract class Cost_accessory extends Inventory {
	/*Decorator class for inventory*/
	public abstract int getPrice();

}

package implementations;

import leveltwo.Pachyderm;

// Hippo class extending Pachyderm and overrides makenoise and roam functions

public class Hippo extends Pachyderm {

   public Hippo(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Hippo makes noise Hipooo.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Hippo exercises by jumping up and down in the water.");
   }
}

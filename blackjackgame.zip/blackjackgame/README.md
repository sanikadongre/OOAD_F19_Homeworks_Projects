README for the Back Jack Game.
--------------------------------

Classes:

Deck
Card
Dealer
Player
GameEngine
--------------------------------

Design Patterns:
Observer
Factory
Decorator

--------------------------------
How to run:

1. Command line:

2. GUI-based:

Notes:

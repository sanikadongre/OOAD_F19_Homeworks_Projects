package src;

public class BasePlayer {
}

package src;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GameEngine {

   Deck deck = new Deck();
   Dealer dealer = new Dealer();
   Player player = new Player();

   public GameEngine () { }
   private final static Logger logger = LogManager.getLogger(GameEngine.class); //prints to console presently.

   public static void main(String[] args) {


      logger.info("--------------- BLACK JACK GAME -----------------");



   }
}

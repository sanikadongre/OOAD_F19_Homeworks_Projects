package src;

public class Player extends BasePlayer{
   Player(){

   }
}

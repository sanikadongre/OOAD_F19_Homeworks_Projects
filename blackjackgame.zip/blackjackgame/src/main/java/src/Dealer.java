package src;

public class Dealer {
   Dealer() {

   }
}

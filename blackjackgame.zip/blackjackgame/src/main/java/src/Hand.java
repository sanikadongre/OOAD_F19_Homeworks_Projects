package src;

public class Hand {

   Hand () {

   }
}

package levelone;

//Top level abstract class: will be inherited in child classes
public abstract class Animal {

   public String name; //property and methods inherited across child classes

   public void wakeUp() {
      System.out.println(this.name + " The animal wakes up.");
   }
   public void sleep() {
      System.out.println(this.name + " The animal sleeps.");
   }

   //Following methods will be overridden
   // some in second level of inheritance/ others in third level of concrete implementations
   public void eat() {
      System.out.println(this.name + " The animal eats.");
   }
   public abstract void makeNoise();
   public abstract void roam();

}

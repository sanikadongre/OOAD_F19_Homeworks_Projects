package implementations;

import leveltwo.Pachyderm;

// Rhino class extending Pachyderm and overrides makenoise and roam functions
public class Rhino extends Pachyderm {

   public Rhino(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Rhino makes noise Rhinooo.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Rhino exercises by jumping up and down in the grass.");
   }
}

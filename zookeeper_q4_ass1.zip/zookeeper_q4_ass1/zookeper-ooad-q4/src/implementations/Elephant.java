package implementations;

import leveltwo.Pachyderm;

// Elephant class extending Pachyderm and overrides makenoise and roam functions
public class Elephant extends Pachyderm {

   public Elephant(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Elephant makes noise Mooooo.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Elephant exercises by moving and bathing in the muddy water.");
   }
}

package implementations;

import leveltwo.Feline;

// Lion class extending Feline and overrides makenoise and roam functions
public class Lion extends Feline {

   public Lion(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Lion makes noise LionGrrr.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Lion exercises by running quick and putting claws in trees.");
   }
}
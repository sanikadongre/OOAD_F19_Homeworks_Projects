package implementations;

import leveltwo.Feline;

public class Cat extends Feline {

   public Cat(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      //use random number generation to select from alternative responses to animal actions
      if(Math.random() < .5){  //Math.random() generates number between 0 & 1
         System.out.println(this.name + " Cat makes noise Meow.");
      } else {
         System.out.println(this.name + " Cat makes noise Meowwww and Meowwww.");
      }
   }

   @Override
   public void roam(){
        //use random number generation to select from alternative responses to animal actions
      if(Math.random() < .5){ //Math.random() generates number between 0 & 1
         System.out.println(this.name + " Cat exercises by stretching and licking itself.");
      } else {
         System.out.println(this.name + " Cat exercises by playing with itself and purring.");
      }
   }
}

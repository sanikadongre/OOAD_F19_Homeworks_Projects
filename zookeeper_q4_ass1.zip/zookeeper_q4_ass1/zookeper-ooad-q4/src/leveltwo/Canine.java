package leveltwo;

import levelone.Animal;

//Canine class extending Animal class and overrides eat and roam function

public abstract class Canine extends Animal {	
   @Override
   public void eat() {
      System.out.println(this.name + " The Canine animal eats meat.");
   }

   @Override
   public void roam() {
      System.out.println(this.name + " The Canine animal roams in pack.");
   }
}

package leveltwo;

import levelone.Animal;

//Feline class extending Animal class and overrides eat and roam function

public abstract class Feline extends Animal { 
   @Override
   public void eat() {
      System.out.println(this.name + " The Feline animal eats raw meat.");
   }

   @Override
   public void roam() {
      System.out.println(this.name + " The Feline animal roams individually/alone.");
   }
}

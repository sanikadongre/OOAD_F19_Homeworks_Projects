package leveltwo;

import levelone.Animal;

//Pachyderm class extending Animal class and overrides eat and roam function

public abstract class Pachyderm extends Animal {

   @Override
   public void eat() {
      System.out.println(this.name + " The Pachyderm animal eats grass and/or some meat.");
   }

   @Override
   public void roam() {
      System.out.println(this.name + " The Pachyderm animal roams in herds or by itself.");
   }
}

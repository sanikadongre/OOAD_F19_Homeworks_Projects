package implementations;

import leveltwo.Canine;

// Dog class extending Canine and overrides makenoise and roam functions
public class Dog extends Canine {

   public Dog(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Dog makes noise Woof.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Dog exercises by stretching and sprinting.");
   }

}

package implementations;

import leveltwo.Canine;

//Wolf class extending Canine and overrides makenoise and roam functions
public class Wolf extends Canine {

   public Wolf(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Wolf makes noise Grrrrr.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Wolf exercises by stretching and licking itself.");
   }
}

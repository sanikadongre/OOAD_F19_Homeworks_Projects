package implementations;

import leveltwo.Feline;

// Tiger class extending Feline and overrides makenoise and roam functions
public class Tiger extends Feline {

   public Tiger(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Tiger makes noise Tigrrrrr.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Tiger exercises by running quick and putting claws in trees.");
   }
}

package main;

import implementations.*;
import levelone.Animal;

import java.io.*;
import java.util.List;
import java.util.ArrayList;

public class Zookeeper {

   List<Animal> animals;

   public static void main(String[] args) throws FileNotFoundException {

      Zookeeper zookeeper = new Zookeeper();

      PrintStream o = new PrintStream(new File("dayatthezoo.txt"));
      System.setOut(o);

      System.out.println("----- Day At the Zoo: Output -----"); //Expected output
      System.out.println("Zoo Opened.");
      System.out.println("");
      zookeeper.createZooAnimals();
      zookeeper.performTasksSequentially();
      System.out.println("");
      System.out.println("Zoo Closed.");
   }

   public void createZooAnimals() {
      animals = new ArrayList<>();
      animals.add(new Cat("Cheshire"));
      animals.add(new Cat("Cuddles"));
      animals.add(new Lion("Leo"));
      animals.add(new Lion("Lewis"));
      animals.add(new Tiger("Tigran"));
      animals.add(new Tiger("Tigru"));
      animals.add(new Elephant("Ellen"));
      animals.add(new Elephant("Elson"));
      animals.add(new Dog("Deo"));
      animals.add(new Dog("Dawn"));
      animals.add(new Hippo("Hank"));
      animals.add(new Hippo("Hustler"));
      animals.add(new Rhino("Rincon"));
      animals.add(new Rhino("Ruben"));
      animals.add(new Tiger("Ruben"));
      animals.add(new Wolf("Will"));
      animals.add(new Wolf("Wiz"));
   }

   public void performTasksSequentially() {

      System.out.println("----------- wakeUpAnimals --------------");
      performFunction("wakeUpAnimals");
      System.out.println("----------- rollCallAnimals --------------");
      performFunction("rollCallAnimals");
      System.out.println("----------- feedAnimals --------------");
      performFunction("feedAnimals");
      System.out.println("------------ exerciseAnimals -------------");
      performFunction("exerciseAnimals");
      System.out.println("------------ shutDownZoo -------------");
      performFunction("shutDownZoo");

   }

   public void performFunction(String task) {
      for (Animal a : animals) {
         switch (task) {
         case "wakeUpAnimals":
            a.wakeUp();
            break;
         case "rollCallAnimals":
            a.makeNoise();
            break;
         case "feedAnimals":
            a.eat();
            break;
         case "exerciseAnimals":
            a.roam();
            break;
         case "shutDownZoo":
            a.sleep();
            break;
         default:
            System.out.println("Invalid task assigned to the zookeeper.");
         }
      }
   }

}

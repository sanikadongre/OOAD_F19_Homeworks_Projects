package implementations;

import leveltwo.Canine;

public class Wolf extends Canine {

   public Wolf(String name) {
      this.name = name;
   }

   @Override
   public void makeNoise(){
      System.out.println(this.name + " Wolf makes noise Grrrrr.");
   }

   @Override
   public void roam(){
      System.out.println(this.name + " Wolf exercises by stretching and licking itself.");
   }
}

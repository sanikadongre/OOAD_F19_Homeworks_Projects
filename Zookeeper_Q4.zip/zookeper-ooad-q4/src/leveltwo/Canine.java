package leveltwo;

import levelone.Animal;

public abstract class Canine extends Animal {

   @Override
   public void eat() {
      System.out.println(this.name + " The Canine animal eats meat.");
   }

   @Override
   public void roam() {
      System.out.println(this.name + " The Canine animal roams in pack.");
   }
}

package leveltwo;

import levelone.Animal;

public abstract class Feline extends Animal {

   @Override
   public void eat() {
      System.out.println(this.name + " The Feline animal eats raw meat.");
   }

   @Override
   public void roam() {
      System.out.println(this.name + " The Feline animal roams individually/alone.");
   }
}

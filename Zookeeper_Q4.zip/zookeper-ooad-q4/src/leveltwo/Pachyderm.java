package leveltwo;

import levelone.Animal;

public abstract class Pachyderm extends Animal {

   @Override
   public void eat() {
      System.out.println(this.name + " The Pachyderm animal eats grass and/or some meat.");
   }

   @Override
   public void roam() {
      System.out.println(this.name + " The Pachyderm animal roams in herds or by itself.");
   }
}
